package modelo;

import java.util.Date;

public class ReportePosicion extends Reporte {

    private String equipoConsultado;

    public ReportePosicion() {
        super();
    }

    public ReportePosicion(String equipoConsultado, Torneo torneo) {
        super(torneo);
        this.equipoConsultado = equipoConsultado;
    }

    public ReportePosicion(String equipoConsultado, Date fechaGeneracion, Torneo torneo) {
        super(fechaGeneracion, torneo);
        this.equipoConsultado = equipoConsultado;
    }

    @Override
    public void generar() {
        
    }

    public String getEquipoConsultado() {
        return equipoConsultado;
    }

    public void setEquipoConsultado(String equipoConsultado) {
        this.equipoConsultado = equipoConsultado;
    }
}
