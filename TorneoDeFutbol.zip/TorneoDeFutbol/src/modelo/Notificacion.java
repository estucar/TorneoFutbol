package modelo;

import java.io.Serializable;
        
public class Notificacion {
    
    private int id;
    private String mensaje;

    public Notificacion() {
    }

    public Notificacion(int id, String mensaje) {
        this.id = id;
        this.mensaje = mensaje;
    }
    
    public void enviar(){
        
    }
    
    public void generarContenido(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    @Override
    public String toString(){
        return mensaje;
    }
}
