package modelo;

import java.io.Serializable;
import java.util.Date;


public abstract class Reporte implements Serializable {

    private int id;
    private Date fechaGeneracion;
    private Torneo torneo;

    public Reporte() {
        this.fechaGeneracion = new Date();
    }

    public Reporte(Torneo torneo) {
        this.fechaGeneracion = new Date();
        this.torneo = torneo;
    }

    public Reporte(Date fechaGeneracion, Torneo torneo) {
        this.fechaGeneracion = fechaGeneracion;
        this.torneo = torneo;
    }

    public abstract void generar();

    public void exportarPDF() {

    }

    public void filtrarDatos() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFechaGeneracion() {
        return fechaGeneracion;
    }

    public void setFechaGeneracion(Date fechaGeneracion) {
        this.fechaGeneracion = fechaGeneracion;
    }

    public Torneo getTorneo() {
        return torneo;
    }

    public void setTorneo(Torneo torneo) {
        this.torneo = torneo;
    }
}