
package modelo;
import java.io.Serializable;

public class PublicoGeneral {
    
    public void consultarEstadadisticas(){
        
    }
    
    public void verPerfilEquipo(){
        
    }
    
    public void verPerfilJugador(){
        
    }
    
    public void consultaFasesTorneo(){
        
    }
    
}
