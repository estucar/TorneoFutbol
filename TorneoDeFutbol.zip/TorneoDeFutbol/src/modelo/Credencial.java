
package modelo;

import java.io.Serializable;

public class Credencial {
    
    private int id;
    private String codigoBarras;

    public Credencial() {
    }
    
    
    public Credencial(int id, String codigoBarras) {
        this.id = id;
        this.codigoBarras = codigoBarras;
    }
    
    public void generar(){
        
    }
    
    public void imprimir(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }
    
    @Override
    public String toString(){
        return "Credencial [Código = " + codigoBarras + " ]";
    }
}
