package modelo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class Torneo {
    
    private int id;
    private String nombre;
    private Date fechaInicio;
    private String faseActual;
    private List<Equipo> equipos;
    private List<Cancha> canchas;

    public Torneo() {
    }

    public Torneo(int id, String nombre, Date fechaInicio, String faseActual, List<Equipo> equipos, List<Cancha> canchas) {
        this.id = id;
        this.nombre = nombre;
        this.fechaInicio = fechaInicio;
        this.faseActual = faseActual;
        this.equipos = new ArrayList<>();
        this.canchas = new ArrayList<>();
    }

    public void registrarAlta(){
        
    }
    
    public void modificar(){
        
    }
    
    public void avanzarFase(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFaseActual() {
        return faseActual;
    }

    public void setFaseActual(String faseActual) {
        this.faseActual = faseActual;
    }

    public List<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(List<Equipo> equipos) {
        this.equipos = equipos;
    }

    public List<Cancha> getCanchas() {
        return canchas;
    }

    public void setCanchas(List<Cancha> canchas) {
        this.canchas = canchas;
    }
    
    
}
