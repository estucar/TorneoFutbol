
package modelo;

import java.io.Serializable;

public class Arbitro extends Usuario {
    
    private int matricula;

    public Arbitro() {
        super();
    }

    public Arbitro(int matricula,int id, long dni, String nombre, String apellido, String email, String contrasenia) {
    super(id, dni, nombre, apellido, email, contrasenia);
    this.matricula = matricula;
    }
    
    public void cargarResultado(){
        
    }
    
    public void registrarIncidente(){
        
    }
    
    public void consultarDisponibilidad(){
        
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    
    
    
}
