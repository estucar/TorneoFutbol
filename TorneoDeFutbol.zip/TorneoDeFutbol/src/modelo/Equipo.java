
package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Equipo {
    
    private int id;
    private String nombre;
    private String categoria;
    private String colorCamiseta;
    private String sedeHabitual;
    private Capitan capitan;
    private List<Jugador> plantel;
    private Inscripcion inscripcion;

    public Equipo(List<Jugador> plantel) {
        this.plantel = new ArrayList<>();
    }
    
    

    public Equipo(int id, String nombre, String categoria, String colorCamiseta, String sedeHabitual, Capitan capitan) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.colorCamiseta = colorCamiseta;
        this.sedeHabitual = sedeHabitual;
        this.capitan = capitan;
        this.plantel = new ArrayList<>();
    }
    
    
    
    public void registrarEquipo(){
        
    }
    
    public void editarEquipo(){
        
    }
    
    public void obtenerEstadisticas(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getColorCamiseta() {
        return colorCamiseta;
    }

    public void setColorCamiseta(String colorCamiseta) {
        this.colorCamiseta = colorCamiseta;
    }

    public String getSedeHabitual() {
        return sedeHabitual;
    }

    public void setSedeHabitual(String sedeHabitual) {
        this.sedeHabitual = sedeHabitual;
    }

    public Capitan getCapitan() {
        return capitan;
    }

    public void setCapitan(Capitan capitan) {
        this.capitan = capitan;
    }

    public List<Jugador> getPlantel() {
        return plantel;
    }

    public void setPlantel(List<Jugador> plantel) {
        this.plantel = plantel;
    }

    public Inscripcion getInscripcion() {
        return inscripcion;
    }

    public void setInscripcion(Inscripcion inscripcion) {
        this.inscripcion = inscripcion;
    }
    
    
    
}
