
package modelo;

import java.io.Serializable;
import java.util.Date;

public class Sancion {
    
    private int id;
    private String tipo;
    private String motivo;
    private Date fechaInicio;
    private Date fechaFin;

    public Sancion() {
    }

    public Sancion(int id, String tipo, String motivo,Date fechaInicio, Date fechaFin) {
        this.id = id;
        this.tipo = tipo;
        this.motivo = motivo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public Sancion(Date fechaInicio, Date fechaFin) {
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }
    
    public void aplicar(){
        
    }
    
    public int calcularDuracion(){
        int duracion = 0;
        return duracion; 
    }
    
    public void verificarVigencia(){
        
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
    
    
}
