package modelo;

import java.util.Date;

public class ReporteSanciones extends Reporte {


    private String jugadorConsulta;

    public ReporteSanciones() {
        super();
    }

 
    public ReporteSanciones(String jugadorConsulta, Torneo torneo) {
        super(torneo);
        this.jugadorConsulta = jugadorConsulta;
    }

    public ReporteSanciones(String jugadorConsulta, Date fechaGeneracion, Torneo torneo) {
        super(fechaGeneracion, torneo);
        this.jugadorConsulta = jugadorConsulta;
    }

    @Override
    public void generar() {
        
    }

    public String getJugadorConsulta() {
        return jugadorConsulta;
    }

    public void setJugadorConsulta(String jugadorConsulta) {
        this.jugadorConsulta = jugadorConsulta;
    }
}