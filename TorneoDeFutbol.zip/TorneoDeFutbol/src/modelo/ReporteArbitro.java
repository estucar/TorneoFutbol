package modelo;

import java.util.Date;

public class ReporteArbitro extends Reporte {

    private int matArbitro;

    public ReporteArbitro() {
        super();
    }

    public ReporteArbitro(int matArbitro, Torneo torneo) {
        super(torneo);
        this.matArbitro = matArbitro;
    }

    public ReporteArbitro(int matArbitro, Date fechaGeneracion, Torneo torneo) {
        super(fechaGeneracion, torneo);
        this.matArbitro = matArbitro;
    }

    @Override
    public void generar() {
        
    }

    public int getMatArbitro() {
        return matArbitro;
    }

    public void setMatArbitro(int matArbitro) {
        this.matArbitro = matArbitro;
    }
}