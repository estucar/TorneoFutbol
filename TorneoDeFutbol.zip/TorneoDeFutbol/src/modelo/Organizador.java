
package modelo;

import java.io.Serializable;

public class Organizador extends AdministradorVip {

    public Organizador() {
    }

    public Organizador(String nivelAcceso) {
        super(nivelAcceso);
    }
    
    
    public void programarPartidos(){
        
    }
    
    public void aplicarSanciones(){
        
    }
    
    public void resolverReclamo(){
        
    }
        
    public void examinarReclamo(){
        
    }
    
    public void evaluarInscripcion(){
        
    }
    
    
}
