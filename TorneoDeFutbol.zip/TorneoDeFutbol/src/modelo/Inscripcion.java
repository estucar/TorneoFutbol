
package modelo;

import java.util.Date;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;


public class Inscripcion {
    
    private int id;
    private Date fecha;
    private String estado;
    private List<String> documentacion;
    private String motivoRechazo;

    public Inscripcion() {
    }
    
    
    public Inscripcion(int id, Date fecha, String estado, List<String> documentacion) {
        this.id = id;
        this.fecha = fecha;
        this.estado = estado;
        this.documentacion = new ArrayList<>();
    }

    public Inscripcion(String motivoRechazo) {
        this.motivoRechazo = motivoRechazo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public List<String> getDocumentacion() {
        return documentacion;
    }

    public void setDocumentacion(List<String> documentacion) {
        this.documentacion = documentacion;
    }

    public String getMotivoRechazo() {
        return motivoRechazo;
    }

    public void setMotivoRechazo(String motivoRechazo) {
        this.motivoRechazo = motivoRechazo;
    }
    
}
