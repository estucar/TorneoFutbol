package modelo;

import java.util.Date;


public class ReporteGoleadores extends Reporte {

    private int cantidadTop;

    public ReporteGoleadores() {
        super();
    }

    public ReporteGoleadores(int cantidadTop, Torneo torneo) {
        super(torneo);
        this.cantidadTop = cantidadTop;
    }

    public ReporteGoleadores(int cantidadTop, Date fechaGeneracion, Torneo torneo) {
        super(fechaGeneracion, torneo);
        this.cantidadTop = cantidadTop;
    }

    @Override
    public void generar() {
        
    }

    public int getCantidadTop() {
        return cantidadTop;
    }

    public void setCantidadTop(int cantidadTop) {
        this.cantidadTop = cantidadTop;
    }
}
