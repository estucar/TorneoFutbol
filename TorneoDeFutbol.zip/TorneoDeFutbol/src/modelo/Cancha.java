
package modelo;

import java.io.Serializable;

public class Cancha {
    
    private int id;
    private String nombre;
    private String ubicacion;
    
    public Cancha(){
    }

    public Cancha(int id, String nombre, String ubicacion) {
        this.id = id;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
    }
    
    public void registrarCancha(){
        
    }
    
    public void modificarCancha(){
        
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }
    
    @Override
    public String toString(){
        return nombre + " (" + ubicacion + ")";
    }
}
