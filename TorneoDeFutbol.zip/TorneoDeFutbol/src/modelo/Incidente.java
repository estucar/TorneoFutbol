
package modelo;

import java.io.Serializable;

public class Incidente {
    
    private int id;
    private String tipo;
    private int minuto;
    private String descripcion;
    private Jugador jugador;

    public Incidente() {
    }

    public Incidente(int id, String tipo, int minuto, String descripcion, Jugador jugador) {
        this.id = id;
        this.tipo = tipo;
        this.minuto = minuto;
        this.descripcion = descripcion;
        this.jugador = jugador;
    }
    
    public void registrar(){
        
    }
    
    public void asociarJugador(){
        
    }
    
    public void asociarTarjeta(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }
    
    
}
