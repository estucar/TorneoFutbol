package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Partido {
    
    private int id;
    private Date fecha;
    private String hora;
    private String estado;
    private String resultado;
    private String motivoPostergacion;
    private String fase;
    private Cancha cancha;
    private Arbitro arbitro;
    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private List<Incidente> incidentes;
    
    public Partido() {
        this.incidentes = new ArrayList<>();
    }

    public Partido(int id, Date fecha, String hora,String fase, Cancha cancha, Equipo equipoLocal, Equipo equipoVisitante) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = "Pendiente";
        this.fase = fase;
        this.cancha = cancha;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.incidentes = new ArrayList<>();
    }
    
    public void programar(){
        
    }
    
    public void cargarResultado(){
        
    }
    
    public void postergar(){
        
    }
    
    public void asignarArbitro(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getMotivoPostergacion() {
        return motivoPostergacion;
    }

    public void setMotivoPostergacion(String motivoPostergacion) {
        this.motivoPostergacion = motivoPostergacion;
    }

    public String getFase() {
        return fase;
    }

    public void setFase(String fase) {
        this.fase = fase;
    }

    public Cancha getCancha() {
        return cancha;
    }

    public void setCancha(Cancha cancha) {
        this.cancha = cancha;
    }

    public Arbitro getArbitro() {
        return arbitro;
    }

    public void setArbitro(Arbitro arbitro) {
        this.arbitro = arbitro;
    }

    public Equipo getEquipoLocal() {
        return equipoLocal;
    }

    public void setEquipoLocal(Equipo equipoLocal) {
        this.equipoLocal = equipoLocal;
    }

    public Equipo getEquipoVisitante() {
        return equipoVisitante;
    }

    public void setEquipoVisitante(Equipo equipoVisitante) {
        this.equipoVisitante = equipoVisitante;
    }

    public List<Incidente> getIncidentes() {
        return incidentes;
    }

    public void setIncidentes(List<Incidente> incidentes) { 
        this.incidentes = incidentes;
    }
    
    
}
