package modelo;

import java.util.Date;

public class HistorialTorneo extends Reporte {

    private String entidadConsultada;

    public HistorialTorneo() {
        super();
    }

    public HistorialTorneo(String entidadConsultada, Torneo torneo) {
        super(torneo);
        this.entidadConsultada = entidadConsultada;
    }

    public HistorialTorneo(String entidadConsultada, Date fechaGeneracion, Torneo torneo) {
        super(fechaGeneracion, torneo);
        this.entidadConsultada = entidadConsultada;
    }

    @Override
    public void generar() {
        
    }


    public String getEntidadConsultada() {
        return entidadConsultada;
    }

    public void setEntidadConsultada(String entidadConsultada) {
        this.entidadConsultada = entidadConsultada;
    }
}