
package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Jugador extends PublicoGeneral{
        
    private int id;
    private long dni;
    private String nombre;
    private String posicion;
    private Date fechaNacimiento;
    private String estado;
    private int goles;
    private int tarjetas;
    private String email;
    private String contrasenia;
    private Credencial credencial;
    private List<Sancion> sanciones;

    public Jugador() {
    }

    public Jugador(int id, long dni, String nombre, String posicion, Date fechaNacimiento, String email, String contrasenia) {
        this.id = id;
        this.dni = dni;
        this.nombre = nombre;
        this.posicion = posicion;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.contrasenia = contrasenia;
    }


    public Jugador(int id, long dni, String nombre, String posicion, Date fechaNacimiento, String estado, String email, String contrasenia) {
        this.id = id;
        this.dni = dni;
        this.nombre = nombre;
        this.posicion = posicion;
        this.fechaNacimiento = fechaNacimiento;
        this.estado = estado;
        this.email = email;
        this.contrasenia = contrasenia;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getGoles() {
        return goles;
    }

    public void setGoles(int goles) {
        this.goles = goles;
    }

    public int getTarjetas() {
        return tarjetas;
    }

    public void setTarjetas(int tarjetas) {
        this.tarjetas = tarjetas;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public Credencial getCredencial() {
        return credencial;
    }

    public void setCredencial(Credencial credencial) {
        this.credencial = credencial;
    }

    public List<Sancion> getSanciones() {
        return sanciones;
    }

    public void setSanciones(List<Sancion> sanciones) {
        this.sanciones = sanciones;
    }
    
    public void iniciarSesionWeb(){
        
    }
    
    public void cerrarSesionWeb(){
        
    }
    
}

