package modelo;

import java.io.Serializable;

public class Administrador extends AdministradorVip {

    public Administrador() {
    }

    public Administrador(String nivelAcceso) {
        super(nivelAcceso);
    }
    
    public void gestionarUsuario(){
        
    }
    
    public void gestionarCancha(){
        
    }
    
    public  void gestionarTorneo(){
        
    }
    
    public void configuracionSistema(){
        
    }
    
    
}
