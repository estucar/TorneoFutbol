
package modelo;
    
import java.io.Serializable;
import java.util.Date;

public class Reclamo {
    
    private int id;
    private Date fecha;
    private String fundamento;
    private String estado;
    private String motivoResolucion;

    public Reclamo() {
    }

    public Reclamo(int id, Date fecha, String fundamento, String estado, String motivoResolucion) {
        this.id = id;
        this.fecha = fecha;
        this.fundamento = fundamento;
        this.estado = estado;
        this.motivoResolucion = motivoResolucion;
    }

    public Reclamo(String estado, String motivoResolucion) {
        this.estado = estado;
        this.motivoResolucion = motivoResolucion;
    }

    public Reclamo(int id, Date fecha, String fundamento) {
        this.id = id;
        this.fecha = fecha;
        this.fundamento = fundamento;
    }
    
    public void iniciar(){
        
    }
    
    public void adjuntarArgumento(){
        
    }
    
    public void resolver(){
        
    }
    
    public void verificarPlazo(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getFundamento() {
        return fundamento;
    }

    public void setFundamento(String fundamento) {
        this.fundamento = fundamento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotivoResolucion() {
        return motivoResolucion;
    }

    public void setMotivoResolucion(String motivoResolucion) {
        this.motivoResolucion = motivoResolucion;
    }
    
}
