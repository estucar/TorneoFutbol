
package modelo;

import java.io.Serializable;

public class AdministradorVip extends Usuario {
    
    private String nivelAcceso;

    public AdministradorVip() {
    }

    public AdministradorVip(String nivelAcceso) {
        this.nivelAcceso = nivelAcceso;
    }
    
    public void gestionarReporte(){
        
    }
    
    public void exportarPDF(){
        
    }

    public String getNivelAcceso() {
        return nivelAcceso;
    }

    public void setNivelAcceso(String nivelAcceso) {
        this.nivelAcceso = nivelAcceso;
    }
    
    
}
