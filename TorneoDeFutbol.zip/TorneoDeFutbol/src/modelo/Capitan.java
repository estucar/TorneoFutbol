
package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Capitan extends Jugador{
    
    private int idCapitan;
    private String nivelAccesoCapitan;
    private List<Reclamo> reclamos;
    
    public void registraEquipo(){
        
    }
    
    public void cargaPlantel(){
        
    }
    
    public void iniciarReclamo(){
        
    }
    
    public void consultarRegistro(){
        
    }
    
    public void cargarDocumentacion(){
        
    }

    public Capitan() {
    }

    public Capitan(int idCapitan, String nivelAccesoCapitan) {
        this.idCapitan = idCapitan;
        this.nivelAccesoCapitan = nivelAccesoCapitan;
    }

    public Capitan(List<Reclamo> reclamos) {
        this.reclamos = new ArrayList<>();
    }
    
    
}
