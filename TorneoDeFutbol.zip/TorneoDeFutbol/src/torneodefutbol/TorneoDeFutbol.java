
package torneodefutbol;

public class TorneoDeFutbol {

    public static void main(String[] args) {
        
    }
    
}
